# Multi-Class Image Classification Project
This project uses MobileNetV2 for image classification.