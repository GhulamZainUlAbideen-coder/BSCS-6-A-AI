from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return "Image Classification API Running Successfully"

@app.route('/predict')
def predict():

    return jsonify({
        "prediction": "forest"
    })

if __name__ == '__main__':
    app.run(debug=True)